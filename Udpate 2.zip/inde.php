<?php
     $linuxdriver = server.dll
    .$language = en
?>