<?php
#get ad with internal
 $ad = showsystem

?>