<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Latihan AlexistDev Domain Lookup</title>
  <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css');?>" >
  <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js');?>"></script>
</head>
<body>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <form method="post" action="<?php echo base_url('index.php/bulan/sewa');?>"role="form">
          <div class="form-group">
            <label> Pilihan Masa Sewa </label>
              <div class="row">
                <div class="col-md-2">
                  <select name="sewa"class="form-control select2" style="width: 100%;">
                    <option selected="selected" value="1">1 Bulan</option>
                    <option value="3">3 Bulan</option>
                    <option value="6">6 Bulan</option>
                    <option value="12">12 Bulan</option>
                  </select>
                </div>
              </div>
          </div>
              <input type="submit" class="btn btn-primary" name="submit" value="sewa">
        </form>
      </div>
    </div>
  </div>
</body>
</html>