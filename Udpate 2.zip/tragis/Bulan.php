<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Bulan extends CI_Controller {
   function __construct(){
     parent::__construct();
     $this->load->helper('form');
   }
   public function index()
   {
     $this->load->view('view_bulan');
   }
   function sewa()
   {
     $bulan = $this->input->post('sewa');
     $tanggalSekarang = date('d-m-Y');
     $tanggalDuedate = date("d-m-Y", strtotime($tanggalSekarang.' + '.$bulan.' Months'));
     echo "tanggal sekarang :".$tanggalSekarang."<br>";
     echo "tanggal overdue :".$tanggalDuedate;
   }
}